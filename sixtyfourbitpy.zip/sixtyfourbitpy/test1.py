import spacy
import numpy
print ("Cool")